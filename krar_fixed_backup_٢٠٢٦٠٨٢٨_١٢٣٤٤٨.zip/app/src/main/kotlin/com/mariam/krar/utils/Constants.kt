package com.mariam.krar.utils

object Constants {
    const val WEB_URL = "https://mariam.top"
    
    // الجديد - الي طلبته
    const val SYSTEM_EMAIL = "info@xprs.top"
    const val SUPPORT_EMAIL = "info@kruri-valverde.com"
    
    // القديم - حتى لا يكسر الملفات الثانية
    const val CONTACT_EMAIL = "info@kruri-valverde.com"
    const val WHATSAPP_NUMBER = "447577351132"
    const val APP_NAME = "كروري فالفيردي🌟"
    const val PREFS_NAME = "app_prefs"
    const val KEY_PRIVACY_ACCEPTED = "privacy_accepted"
    const val FCM_TOPIC = "all_users"
}