package com.mariam.krar.data

data class Note(
    val id: String,
    val title: String,
    val content: String,
    val imageUri: String? = null,
    val linkLabel: String? = null,
    val linkUrl: String? = null,
    val updatedAt: Long = System.currentTimeMillis()
)