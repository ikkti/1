package com.mariam.krar.utils

object SupportWidgetHtml {
    val html = """
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>دعم كروري فالفيردي</title>
<style>
body{margin:0;background:#07111f;font-family:Arial,sans-serif;overflow:hidden}
#fm-ai-widget{position:fixed;inset:0;z-index:99999;font-family:'Cairo',sans-serif}
#fm-widget-btn{display:none}
#fm-chat-window{position:absolute;inset:0;width:100%;height:100%;background:#0f0f14;display:flex;flex-direction:column;overflow:hidden;border:none;box-shadow:none}
@keyframes fmUp{from{opacity:0;transform:translateY(12px) scale(.98)}to{opacity:1;transform:translateY(0) scale(1)}}
@keyframes fmDot{0%,100%{transform:translateY(0)}50%{transform:translateY(-5px)}}
#fm-messages{flex:1;padding:14px;overflow-y:auto;background:#0a0a0f;display:flex;flex-direction:column;gap:10px}
.fm-bubble{padding:10px 14px;border-radius:18px;font-size:13.5px;line-height:1.6;max-width:82%;word-break:break-word;animation:fmUp .25s ease}
.fm-user{align-self:flex-end;background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;border-bottom-right-radius:6px}
.fm-bot{align-self:flex-start;background:#1c1c26;color:#e8e8ed;border:1px solid #23232f;border-bottom-left-radius:6px}
.fm-quick{padding:6px 12px;background:#1c1c26;border:1px solid #2a2a3a;color:#a0a0b0;border-radius:20px;font-size:12px;cursor:pointer;transition:.2s}
#fm-quick-wrap{display:flex;gap:6px;padding:8px 14px;overflow-x:auto}
textarea{font-family:inherit}
</style>
</head>
<body>
<div id="fm-ai-widget" dir="rtl">
<button id="fm-widget-btn"><span id="fm-btn-icon" style="font-size:26px">💬</span></button>
<div id="fm-chat-window" class="show">
  <div style="padding:14px 16px;display:flex;justify-content:space-between;align-items:center;background:#12121a;border-bottom:1px solid #23232f">
    <div style="display:flex;align-items:center;gap:10px">
      <div style="width:34px;height:34px;background:linear-gradient(135deg,#6366f1,#8b5cf6);border-radius:10px;display:flex;align-items:center;justify-content:center">🤖</div>
      <div>
        <div style="color:#fff;font-weight:700;font-size:13px">كروري فالفيردي 🌟</div>
        <div id="fm-status" style="font-size:11px;color:#22c55e">● متصل الآن</div>
      </div>
    </div>
    <button onclick="fmClear()" style="background:0;border:0;color:#666;font-size:18px;cursor:pointer">🗑️</button>
  </div>
  <div id="fm-messages"></div>
  <div id="fm-typing" style="display:none;padding:0 14px 10px;align-items:center;gap:8px">
    <div style="width:28px;height:28px;background:linear-gradient(135deg,#6366f1,#8b5cf6);border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:13px">🤖</div>
    <div style="background:#1c1c26;border:1px solid #23232f;padding:10px 14px;border-radius:16px;display:flex;align-items:center;gap:6px">
      <span style="font-size:11px;color:#8b8b9a;margin-left:4px">كروري يكتب</span>
      <span style="width:5px;height:5px;background:#6366f1;border-radius:50%;animation:fmDot 1s infinite"></span>
      <span style="width:5px;height:5px;background:#8b5cf6;border-radius:50%;animation:fmDot 1s .15s infinite"></span>
      <span style="width:5px;height:5px;background:#a78bfa;border-radius:50%;animation:fmDot 1s .3s infinite"></span>
    </div>
  </div>
  <div id="fm-quick-wrap">
    <button class="fm-quick" onclick="fmSendQuick('شلونك؟')">شلونك؟ 👋</button>
    <button class="fm-quick" onclick="fmSendQuick('ساعدني')">ساعدني ✨</button>
    <button class="fm-quick" onclick="fmSendQuick('شنو الأخبار؟')">الأخبار 📰</button>
  </div>
  <div style="display:flex;gap:8px;padding:12px;background:#12121a;border-top:1px solid #23232f;align-items:center">
    <textarea id="fm-input" placeholder="اكتب هنا..." rows="1" style="flex:1;background:#1c1c26;border:1px solid #2a2a3a;border-radius:12px;padding:11px 14px;color:#fff;outline:none;resize:none;font-family:inherit;font-size:13px;max-height:80px"></textarea>
    <button id="fm-send" style="width:42px;height:42px;background:linear-gradient(135deg,#6366f1,#8b5cf6);border:none;border-radius:12px;color:#fff;cursor:pointer;font-size:16px;transition:.2s">➤</button>
  </div>
</div>
</div>
<script>
(function(){
  const API_URL='https://xkvs.pythonanywhere.com/api/bot';
  const API_KEY='FM.AI_kwW31RHj2u36aZcvh0TFkP7JDtDAhh';
  const KEY='fm_v3';
  let loading=false;
  const $=id=>document.getElementById(id);
  const msgs=$('fm-messages'),input=$('fm-input'),typing=$('fm-typing'),send=$('fm-send');
  function init(){
    send.onclick=doSend;
    input.onkeydown=e=>{ if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();doSend()} };
    input.oninput=()=>{ input.style.height='auto'; input.style.height=Math.min(input.scrollHeight,80)+'px'; };
    load();
  }
  function bubble(text,type){
    const d=document.createElement('div'); d.className='fm-bubble '+(type==='user'?'fm-user':'fm-bot');
    d.innerHTML=text.replace(/\n/g,'<br>');
    msgs.appendChild(d); msgs.scrollTo({top:msgs.scrollHeight,behavior:'smooth'});
    localStorage.setItem(KEY,msgs.innerHTML);
  }
  async function doSend(){
    const t=input.value.trim(); if(!t||loading) return;
    bubble(t,'user'); input.value=''; input.style.height='auto';
    loading=true; typing.style.display='flex'; msgs.scrollTop=msgs.scrollHeight;
    try{
      const r=await fetch(API_URL,{method:'POST',headers:{'Authorization':'Bearer '+API_KEY,'Content-Type':'application/json'},body:JSON.stringify({message:t})});
      const j=await r.json(); typing.style.display='none';
      if(r.ok&&j.reply) bubble(j.reply,'bot');
      else bubble('❌ صار خطأ، حاول مرة ثانية','bot');
    }catch(e){ typing.style.display='none'; bubble('❌ ماكو اتصال بالسيرفر','bot'); }
    loading=false;
  }
  function load(){
    const h=localStorage.getItem(KEY);
    if(h) msgs.innerHTML=h; else bubble('هلا والله! 👋\nأنا كروري فالفيردي 🌟\nشنو تريد اساعدك بيه اليوم؟','bot');
    msgs.scrollTop=msgs.scrollHeight;
  }
  window.fmClear=()=>{ if(confirm('تمسح المحادثة؟')){ localStorage.removeItem(KEY); msgs.innerHTML=''; bubble('تم المسح ✅ ابدي من جديد!','bot'); } };
  window.fmSendQuick=t=>{ input.value=t; doSend(); };
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',init); else init();
})();
</script>
</body>
</html>
""".trimIndent()
}