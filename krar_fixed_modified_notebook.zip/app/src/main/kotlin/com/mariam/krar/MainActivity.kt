package com.mariam.krar

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.webkit.WebView
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.core.view.GravityCompat
import androidx.core.view.isGone
import androidx.core.view.isVisible
import androidx.drawerlayout.widget.DrawerLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.navigation.NavigationView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.mariam.krar.data.Note
import com.mariam.krar.data.UserProfile
import com.mariam.krar.storage.LocalStore
import com.mariam.krar.ui.NoteAdapter
import com.mariam.krar.ui.dialogs.PrivacyDialog
import com.mariam.krar.utils.Constants
import com.mariam.krar.utils.SupportWidgetHtml
import java.util.UUID

class MainActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var googleClient: GoogleSignInClient
    private lateinit var adapter: NoteAdapter

    private lateinit var loginRoot: View
    private lateinit var drawerRoot: DrawerLayout
    private lateinit var toolbar: MaterialToolbar
    private lateinit var navigationView: NavigationView
    private lateinit var notesRecycler: RecyclerView
    private lateinit var emptyState: LinearLayout
    private lateinit var btnAddNote: FloatingActionButton
    private lateinit var btnShareNotebook: MaterialButton
    private lateinit var btnEmailAuth: MaterialButton
    private lateinit var btnGoogleAuth: MaterialButton
    private lateinit var tvSwitchAuth: TextView
    private lateinit var tvForgotPassword: TextView
    private lateinit var etName: EditText
    private lateinit var etEmail: EditText
    private lateinit var etPassword: EditText
    private lateinit var lockOverlay: View
    private lateinit var btnUnlockNow: MaterialButton

    private var isRegisterMode = false
    private var biometricUnlockedThisSession = false
    private var onImagePicked: ((Uri?) -> Unit)? = null

    private val googleLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
        try {
            val account = task.getResult(ApiException::class.java)
            val credential = GoogleAuthProvider.getCredential(account.idToken, null)
            auth.signInWithCredential(credential)
                .addOnSuccessListener {
                    LocalStore.saveProfileFromUser(this, auth.currentUser!!)
                    showContentAfterLogin()
                }
                .addOnFailureListener { showToast(it.message ?: "فشل تسجيل الدخول عبر Google") }
        } catch (e: Exception) {
            showToast("تعذر تسجيل الدخول عبر Google")
        }
    }

    private val imagePickerLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            val uri = result.data?.data
            uri?.let {
                try {
                    contentResolver.takePersistableUriPermission(
                        it,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (_: Exception) {
                }
            }
            onImagePicked?.invoke(uri)
        } else {
            onImagePicked?.invoke(null)
        }
        onImagePicked = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        applyThemeFromStorage()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        auth = FirebaseAuth.getInstance()
        setupGoogleSignIn()
        bindViews()
        setupToolbarAndDrawer()
        setupNotesList()
        setupLoginActions()
        setupMainActions()
        maybeShowPrivacyDialog()

        if (auth.currentUser != null) {
            LocalStore.saveProfileFromUser(this, auth.currentUser!!)
            showContentAfterLogin()
        } else {
            showLoginOnly()
        }
    }

    private fun bindViews() {
        loginRoot = findViewById(R.id.loginRoot)
        drawerRoot = findViewById(R.id.drawerRoot)
        toolbar = findViewById(R.id.topToolbar)
        navigationView = findViewById(R.id.navigationView)
        notesRecycler = findViewById(R.id.recyclerNotes)
        emptyState = findViewById(R.id.emptyState)
        btnAddNote = findViewById(R.id.fabAddNote)
        btnShareNotebook = findViewById(R.id.btnShareNotebook)
        btnEmailAuth = findViewById(R.id.btnEmailAuth)
        btnGoogleAuth = findViewById(R.id.btnGoogleAuth)
        tvSwitchAuth = findViewById(R.id.tvSwitchAuth)
        tvForgotPassword = findViewById(R.id.tvForgotPassword)
        etName = findViewById(R.id.etName)
        etEmail = findViewById(R.id.etEmail)
        etPassword = findViewById(R.id.etPassword)
        lockOverlay = findViewById(R.id.lockOverlay)
        btnUnlockNow = findViewById(R.id.btnUnlockNow)
    }

    private fun setupToolbarAndDrawer() {
        setSupportActionBar(toolbar)
        toolbar.setNavigationIcon(android.R.drawable.ic_menu_sort_by_size)
        toolbar.setNavigationOnClickListener { drawerRoot.openDrawer(GravityCompat.START) }
        navigationView.setNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_notes -> drawerRoot.closeDrawer(GravityCompat.START)
                R.id.nav_profile -> {
                    showProfileDialog()
                    drawerRoot.closeDrawer(GravityCompat.START)
                }
                R.id.nav_share_notebook -> {
                    shareNotebook()
                    drawerRoot.closeDrawer(GravityCompat.START)
                }
                R.id.nav_support -> {
                    showSupportDialog()
                    drawerRoot.closeDrawer(GravityCompat.START)
                }
                R.id.nav_theme -> {
                    toggleTheme()
                    drawerRoot.closeDrawer(GravityCompat.START)
                }
                R.id.nav_biometric -> {
                    toggleBiometricLock()
                    drawerRoot.closeDrawer(GravityCompat.START)
                }
                R.id.nav_logout -> {
                    logout()
                    drawerRoot.closeDrawer(GravityCompat.START)
                }
            }
            true
        }
        refreshDrawerMenuTitles()
    }

    private fun setupNotesList() {
        adapter = NoteAdapter(
            mutableListOf(),
            onEdit = { showNoteEditor(it) },
            onDelete = { confirmDelete(it) },
            onShare = { shareNote(it) },
            onOpenLink = { openLink(it.linkUrl) }
        )
        notesRecycler.layoutManager = LinearLayoutManager(this)
        notesRecycler.adapter = adapter
    }

    private fun setupLoginActions() {
        updateAuthModeUi()
        btnEmailAuth.setOnClickListener {
            val email = etEmail.text.toString().trim()
            val password = etPassword.text.toString().trim()
            val name = etName.text.toString().trim()

            if (email.isBlank() || password.isBlank()) {
                showToast("اكتب البريد وكلمة المرور")
                return@setOnClickListener
            }

            if (isRegisterMode) {
                if (name.isBlank()) {
                    showToast("اكتب اسمك حتى يتجهز الملف الشخصي")
                    return@setOnClickListener
                }
                if (password.length < 6) {
                    showToast("كلمة المرور لازم تكون 6 أحرف أو أكثر")
                    return@setOnClickListener
                }
                auth.createUserWithEmailAndPassword(email, password)
                    .addOnSuccessListener {
                        auth.currentUser?.updateProfile(
                            com.google.firebase.auth.UserProfileChangeRequest.Builder()
                                .setDisplayName(name)
                                .build()
                        )?.addOnCompleteListener {
                            LocalStore.saveProfile(
                                this,
                                UserProfile(
                                    name = name,
                                    email = email,
                                    bio = "",
                                    photoUrl = "",
                                    provider = "email"
                                )
                            )
                            showContentAfterLogin()
                        }
                    }
                    .addOnFailureListener { showToast(it.message ?: "تعذر إنشاء الحساب") }
            } else {
                auth.signInWithEmailAndPassword(email, password)
                    .addOnSuccessListener {
                        LocalStore.saveProfileFromUser(this, auth.currentUser!!)
                        showContentAfterLogin()
                    }
                    .addOnFailureListener { showToast(it.message ?: "بيانات الدخول غير صحيحة") }
            }
        }

        btnGoogleAuth.setOnClickListener {
            googleLauncher.launch(googleClient.signInIntent)
        }

        tvSwitchAuth.setOnClickListener {
            isRegisterMode = !isRegisterMode
            updateAuthModeUi()
        }

        tvForgotPassword.setOnClickListener {
            val email = etEmail.text.toString().trim()
            if (email.isBlank()) {
                showToast("اكتب البريد أولاً")
                return@setOnClickListener
            }
            auth.sendPasswordResetEmail(email)
                .addOnSuccessListener { showToast("تم إرسال رابط إعادة تعيين كلمة المرور") }
                .addOnFailureListener { showToast(it.message ?: "تعذر إرسال الرابط") }
        }
    }

    private fun setupMainActions() {
        btnAddNote.setOnClickListener { showNoteEditor(null) }
        btnShareNotebook.setOnClickListener { shareNotebook() }
        btnUnlockNow.setOnClickListener { requestBiometricUnlock() }
    }

    private fun maybeShowPrivacyDialog() {
        val prefs = getSharedPreferences(Constants.PREFS_NAME, MODE_PRIVATE)
        if (!prefs.getBoolean(Constants.KEY_PRIVACY_ACCEPTED, false)) {
            PrivacyDialog(this).show()
        }
    }

    private fun setupGoogleSignIn() {
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(getString(R.string.default_web_client_id))
            .requestEmail()
            .build()
        googleClient = GoogleSignIn.getClient(this, gso)
    }

    private fun showLoginOnly() {
        loginRoot.isVisible = true
        drawerRoot.isGone = true
        lockOverlay.isGone = true
    }

    private fun showContentAfterLogin() {
        loginRoot.isGone = true
        drawerRoot.isVisible = true
        refreshProfileHeader()
        loadNotes()
        if (LocalStore.isBiometricEnabled(this)) {
            lockOverlay.isVisible = true
            if (!biometricUnlockedThisSession) requestBiometricUnlock()
        } else {
            lockOverlay.isGone = true
        }
    }

    private fun updateAuthModeUi() {
        etName.isVisible = isRegisterMode
        btnEmailAuth.text = if (isRegisterMode) "إنشاء الحساب" else "تسجيل الدخول"
        tvSwitchAuth.text = if (isRegisterMode) "عندي حساب بالفعل" else "إنشاء حساب جديد"
        tvForgotPassword.isVisible = !isRegisterMode
    }

    private fun loadNotes() {
        val notes = LocalStore.getNotes(this)
        adapter.update(notes)
        emptyState.isVisible = notes.isEmpty()
    }

    private fun showNoteEditor(note: Note?) {
        val dialogView = layoutInflater.inflate(R.layout.dialog_note_editor, null)
        val title = dialogView.findViewById<EditText>(R.id.etNoteTitle)
        val content = dialogView.findViewById<EditText>(R.id.etNoteContent)
        val linkLabel = dialogView.findViewById<EditText>(R.id.etLinkLabel)
        val linkUrl = dialogView.findViewById<EditText>(R.id.etLinkUrl)
        val imagePreview = dialogView.findViewById<ImageView>(R.id.ivSelectedImage)
        val btnPickImage = dialogView.findViewById<MaterialButton>(R.id.btnPickImage)
        val btnRemoveImage = dialogView.findViewById<MaterialButton>(R.id.btnRemoveImage)

        title.setText(note?.title.orEmpty())
        content.setText(note?.content.orEmpty())
        linkLabel.setText(note?.linkLabel.orEmpty())
        linkUrl.setText(note?.linkUrl.orEmpty())

        var imageUriString = note?.imageUri.orEmpty()
        if (imageUriString.isNotBlank()) {
            imagePreview.isVisible = true
            imagePreview.setImageURI(Uri.parse(imageUriString))
        } else {
            imagePreview.isGone = true
        }

        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .create()

        btnPickImage.setOnClickListener {
            onImagePicked = { uri ->
                if (uri != null) {
                    imageUriString = uri.toString()
                    imagePreview.isVisible = true
                    imagePreview.setImageURI(uri)
                }
            }
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "image/*"
                addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            imagePickerLauncher.launch(intent)
        }

        btnRemoveImage.setOnClickListener {
            imageUriString = ""
            imagePreview.setImageDrawable(null)
            imagePreview.isGone = true
        }

        dialogView.findViewById<MaterialButton>(R.id.btnSaveNote).setOnClickListener {
            val newNote = Note(
                id = note?.id ?: UUID.randomUUID().toString(),
                title = title.text.toString().trim(),
                content = content.text.toString().trim(),
                imageUri = imageUriString.ifBlank { null },
                linkLabel = linkLabel.text.toString().trim().ifBlank { null },
                linkUrl = linkUrl.text.toString().trim().ifBlank { null },
                updatedAt = System.currentTimeMillis()
            )
            if (newNote.title.isBlank() && newNote.content.isBlank()) {
                showToast("اكتب عنوان أو محتوى للملاحظة")
                return@setOnClickListener
            }
            LocalStore.upsertNote(this, newNote)
            loadNotes()
            dialog.dismiss()
        }

        dialogView.findViewById<MaterialButton>(R.id.btnCancelNote).setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    private fun showProfileDialog() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_profile, null)
        val profile = LocalStore.getProfile(this)
        val user = auth.currentUser

        val ivProfile = dialogView.findViewById<ImageView>(R.id.ivProfileLarge)
        val etProfileName = dialogView.findViewById<EditText>(R.id.etProfileName)
        val etProfileEmail = dialogView.findViewById<EditText>(R.id.etProfileEmail)
        val etProfileBio = dialogView.findViewById<EditText>(R.id.etProfileBio)
        val etProfilePhotoUrl = dialogView.findViewById<EditText>(R.id.etProfilePhotoUrl)
        val etNewPassword = dialogView.findViewById<EditText>(R.id.etNewPassword)
        val tvProvider = dialogView.findViewById<TextView>(R.id.tvProfileProvider)

        etProfileName.setText(profile?.name ?: user?.displayName.orEmpty())
        etProfileEmail.setText(profile?.email ?: user?.email.orEmpty())
        etProfileBio.setText(profile?.bio.orEmpty())
        etProfilePhotoUrl.setText(profile?.photoUrl.orEmpty())
        val provider = profile?.provider ?: if (user?.providerData?.any { it.providerId == "google.com" } == true) "Google" else "بريد إلكتروني"
        tvProvider.text = "طريقة الدخول: $provider"
        ivProfile.load(profile?.photoUrl ?: user?.photoUrl) {
            placeholder(R.mipmap.ic_launcher)
            error(R.mipmap.ic_launcher)
        }

        val dialog = AlertDialog.Builder(this).setView(dialogView).create()

        dialogView.findViewById<MaterialButton>(R.id.btnPreviewPhoto).setOnClickListener {
            ivProfile.load(etProfilePhotoUrl.text.toString().trim()) {
                placeholder(R.mipmap.ic_launcher)
                error(R.mipmap.ic_launcher)
            }
        }

        dialogView.findViewById<MaterialButton>(R.id.btnSaveProfile).setOnClickListener {
            val updatedProfile = UserProfile(
                name = etProfileName.text.toString().trim().ifBlank { "مستخدم التطبيق" },
                email = etProfileEmail.text.toString().trim(),
                bio = etProfileBio.text.toString().trim(),
                photoUrl = etProfilePhotoUrl.text.toString().trim(),
                provider = profile?.provider ?: "email"
            )
            LocalStore.saveProfile(this, updatedProfile)
            auth.currentUser?.updateProfile(
                com.google.firebase.auth.UserProfileChangeRequest.Builder()
                    .setDisplayName(updatedProfile.name)
                    .setPhotoUri(updatedProfile.photoUrl.takeIf { it.isNotBlank() }?.let { Uri.parse(it) })
                    .build()
            )
            if (user != null && updatedProfile.email.isNotBlank() && updatedProfile.email != user.email) {
                user.updateEmail(updatedProfile.email)
            }
            val newPassword = etNewPassword.text.toString().trim()
            if (newPassword.length >= 6 && profile?.provider != "google") {
                user?.updatePassword(newPassword)
            }
            refreshProfileHeader()
            showToast("تم تحديث الملف الشخصي")
            dialog.dismiss()
        }

        dialogView.findViewById<MaterialButton>(R.id.btnCloseProfile).setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    private fun refreshProfileHeader() {
        val header = navigationView.getHeaderView(0)
        val profile = LocalStore.getProfile(this)
        val user = auth.currentUser
        header.findViewById<TextView>(R.id.tvHeaderName).text = profile?.name ?: user?.displayName ?: "مستخدم التطبيق"
        header.findViewById<TextView>(R.id.tvHeaderEmail).text = profile?.email ?: user?.email ?: ""
        header.findViewById<TextView>(R.id.tvHeaderBio).text = profile?.bio?.ifBlank { "مفكرتك جاهزة للتدوين السريع والصور والروابط" }
            ?: "مفكرتك جاهزة للتدوين السريع والصور والروابط"
        header.findViewById<ImageView>(R.id.ivHeaderAvatar).load(profile?.photoUrl ?: user?.photoUrl) {
            placeholder(R.mipmap.ic_launcher)
            error(R.mipmap.ic_launcher)
        }
    }

    private fun showSupportDialog() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_support, null)
        val webView = dialogView.findViewById<WebView>(R.id.supportWebView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.loadDataWithBaseURL(null, SupportWidgetHtml.html, "text/html", "utf-8", null)

        val dialog = AlertDialog.Builder(this).setView(dialogView).create()
        dialogView.findViewById<MaterialButton>(R.id.btnCloseSupport).setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    private fun confirmDelete(note: Note) {
        AlertDialog.Builder(this)
            .setTitle("حذف الملاحظة")
            .setMessage("متأكد تريد حذف: ${note.title.ifBlank { "ملاحظة بدون عنوان" }}؟")
            .setPositiveButton("حذف") { _, _ ->
                LocalStore.deleteNote(this, note.id)
                loadNotes()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun shareNote(note: Note) {
        val text = buildString {
            append(note.title.ifBlank { "ملاحظة" })
            append("\n\n")
            append(note.content)
            if (!note.linkUrl.isNullOrBlank()) {
                append("\n\n")
                append(note.linkLabel ?: "رابط")
                append(": ")
                append(note.linkUrl)
            }
        }
        shareText(text)
    }

    private fun shareNotebook() {
        val notes = LocalStore.getNotes(this)
        if (notes.isEmpty()) {
            showToast("المفكرة فارغة حالياً")
            return
        }
        val text = buildString {
            append("مفكرة ")
            append(getString(R.string.app_name))
            append("\n\n")
            notes.forEachIndexed { index, note ->
                append(index + 1)
                append(". ")
                append(note.title.ifBlank { "ملاحظة بدون عنوان" })
                append("\n")
                append(note.content)
                if (!note.linkUrl.isNullOrBlank()) {
                    append("\n")
                    append(note.linkLabel ?: "رابط")
                    append(": ")
                    append(note.linkUrl)
                }
                append("\n\n")
            }
        }
        shareText(text)
    }

    private fun shareText(text: String) {
        startActivity(
            Intent.createChooser(
                Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, text)
                },
                "مشاركة"
            )
        )
    }

    private fun openLink(url: String?) {
        if (url.isNullOrBlank()) return
        val fixed = if (url.startsWith("http")) url else "https://$url"
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(fixed)))
    }

    private fun toggleTheme() {
        val next = !LocalStore.isNightMode(this)
        LocalStore.setNightMode(this, next)
        AppCompatDelegate.setDefaultNightMode(if (next) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO)
        recreate()
    }

    private fun refreshDrawerMenuTitles() {
        navigationView.menu.findItem(R.id.nav_theme).title =
            if (LocalStore.isNightMode(this)) "الوضع النهاري" else "الوضع الليلي"
        navigationView.menu.findItem(R.id.nav_biometric).title =
            if (LocalStore.isBiometricEnabled(this)) "إيقاف قفل البصمة" else "تفعيل قفل البصمة"
    }

    private fun toggleBiometricLock() {
        val enabled = LocalStore.isBiometricEnabled(this)
        if (enabled) {
            LocalStore.setBiometricEnabled(this, false)
            biometricUnlockedThisSession = false
            lockOverlay.isGone = true
            refreshDrawerMenuTitles()
            showToast("تم إيقاف قفل البصمة")
        } else {
            requestBiometricUnlock(enableAfterSuccess = true)
        }
    }

    private fun requestBiometricUnlock(enableAfterSuccess: Boolean = false) {
        val biometricManager = BiometricManager.from(this)
        val canAuth = biometricManager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK)
        if (canAuth != BiometricManager.BIOMETRIC_SUCCESS) {
            showToast("البصمة غير متاحة على هذا الجهاز")
            return
        }

        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle(if (enableAfterSuccess) "تفعيل قفل البصمة" else "فتح المفكرة")
            .setSubtitle("ثبت هويتك بالبصمة للوصول للمفكرة")
            .setNegativeButtonText("إلغاء")
            .build()

        val executor = ContextCompat.getMainExecutor(this)
        val biometricPrompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                super.onAuthenticationSucceeded(result)
                biometricUnlockedThisSession = true
                lockOverlay.isGone = true
                if (enableAfterSuccess) {
                    LocalStore.setBiometricEnabled(this@MainActivity, true)
                    refreshDrawerMenuTitles()
                    showToast("تم تفعيل قفل البصمة")
                }
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                super.onAuthenticationError(errorCode, errString)
                if (!enableAfterSuccess && LocalStore.isBiometricEnabled(this@MainActivity)) {
                    lockOverlay.isVisible = true
                }
            }
        })
        biometricPrompt.authenticate(promptInfo)
    }

    private fun logout() {
        biometricUnlockedThisSession = false
        auth.signOut()
        googleClient.signOut()
        showLoginOnly()
        showToast("تم تسجيل الخروج")
    }

    private fun applyThemeFromStorage() {
        AppCompatDelegate.setDefaultNightMode(
            if (LocalStore.isNightMode(this)) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
        )
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun onBackPressed() {
        if (drawerRoot.isVisible && drawerRoot.isDrawerOpen(GravityCompat.START)) {
            drawerRoot.closeDrawer(GravityCompat.START)
        } else {
            super.onBackPressed()
        }
    }
}