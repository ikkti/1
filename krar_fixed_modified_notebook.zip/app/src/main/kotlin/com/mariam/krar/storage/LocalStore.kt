package com.mariam.krar.storage

import android.content.Context
import com.google.firebase.auth.FirebaseUser
import com.mariam.krar.data.Note
import com.mariam.krar.data.UserProfile
import org.json.JSONArray
import org.json.JSONObject

object LocalStore {
    private const val PREFS = "krar_notebook_prefs"
    private const val KEY_NOTES = "notes"
    private const val KEY_PROFILE = "profile"
    private const val KEY_NIGHT = "night_mode"
    private const val KEY_BIOMETRIC = "biometric_enabled"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun getNotes(context: Context): MutableList<Note> {
        val raw = prefs(context).getString(KEY_NOTES, "[]") ?: "[]"
        val arr = JSONArray(raw)
        val notes = mutableListOf<Note>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            notes += Note(
                id = o.optString("id"),
                title = o.optString("title"),
                content = o.optString("content"),
                imageUri = o.optString("imageUri").ifBlank { null },
                linkLabel = o.optString("linkLabel").ifBlank { null },
                linkUrl = o.optString("linkUrl").ifBlank { null },
                updatedAt = o.optLong("updatedAt", System.currentTimeMillis())
            )
        }
        return notes.sortedByDescending { it.updatedAt }.toMutableList()
    }

    fun upsertNote(context: Context, note: Note) {
        val notes = getNotes(context)
        val index = notes.indexOfFirst { it.id == note.id }
        if (index >= 0) notes[index] = note else notes.add(0, note)
        saveNotes(context, notes.sortedByDescending { it.updatedAt })
    }

    fun deleteNote(context: Context, noteId: String) {
        val filtered = getNotes(context).filterNot { it.id == noteId }
        saveNotes(context, filtered)
    }

    private fun saveNotes(context: Context, notes: List<Note>) {
        val arr = JSONArray()
        notes.forEach { n ->
            arr.put(
                JSONObject().apply {
                    put("id", n.id)
                    put("title", n.title)
                    put("content", n.content)
                    put("imageUri", n.imageUri ?: "")
                    put("linkLabel", n.linkLabel ?: "")
                    put("linkUrl", n.linkUrl ?: "")
                    put("updatedAt", n.updatedAt)
                }
            )
        }
        prefs(context).edit().putString(KEY_NOTES, arr.toString()).apply()
    }

    fun getProfile(context: Context): UserProfile? {
        val raw = prefs(context).getString(KEY_PROFILE, null) ?: return null
        val o = JSONObject(raw)
        return UserProfile(
            name = o.optString("name"),
            email = o.optString("email"),
            bio = o.optString("bio"),
            photoUrl = o.optString("photoUrl"),
            provider = o.optString("provider", "email")
        )
    }

    fun saveProfile(context: Context, profile: UserProfile) {
        val o = JSONObject().apply {
            put("name", profile.name)
            put("email", profile.email)
            put("bio", profile.bio)
            put("photoUrl", profile.photoUrl)
            put("provider", profile.provider)
        }
        prefs(context).edit().putString(KEY_PROFILE, o.toString()).apply()
    }

    fun saveProfileFromUser(context: Context, user: FirebaseUser, fallbackName: String = "") {
        val existing = getProfile(context)
        val provider = if (user.providerData.any { it.providerId == "google.com" }) "google" else "email"
        val profile = UserProfile(
            name = existing?.name?.takeIf { it.isNotBlank() }
                ?: user.displayName?.takeIf { it.isNotBlank() }
                ?: fallbackName.ifBlank { user.email?.substringBefore('@') ?: "مستخدم التطبيق" },
            email = user.email ?: existing?.email.orEmpty(),
            bio = existing?.bio.orEmpty(),
            photoUrl = existing?.photoUrl?.takeIf { it.isNotBlank() }
                ?: user.photoUrl?.toString().orEmpty(),
            provider = provider
        )
        saveProfile(context, profile)
    }

    fun setNightMode(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_NIGHT, enabled).apply()
    }

    fun isNightMode(context: Context): Boolean = prefs(context).getBoolean(KEY_NIGHT, true)

    fun setBiometricEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_BIOMETRIC, enabled).apply()
    }

    fun isBiometricEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_BIOMETRIC, false)

    fun clearSessionData(context: Context) {
        prefs(context).edit().remove(KEY_BIOMETRIC).apply()
    }
}