package com.mariam.krar.data

data class UserProfile(
    val name: String,
    val email: String,
    val bio: String = "",
    val photoUrl: String = "",
    val provider: String = "email"
)