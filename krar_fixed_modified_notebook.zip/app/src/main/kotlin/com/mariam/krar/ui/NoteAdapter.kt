package com.mariam.krar.ui

import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.mariam.krar.R
import com.mariam.krar.data.Note
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class NoteAdapter(
    private val notes: MutableList<Note>,
    private val onEdit: (Note) -> Unit,
    private val onDelete: (Note) -> Unit,
    private val onShare: (Note) -> Unit,
    private val onOpenLink: (Note) -> Unit
) : RecyclerView.Adapter<NoteAdapter.NoteViewHolder>() {

    private val formatter = SimpleDateFormat("dd/MM/yyyy • hh:mm a", Locale("ar"))

    inner class NoteViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val card: MaterialCardView = view.findViewById(R.id.noteCard)
        val title: TextView = view.findViewById(R.id.tvNoteTitle)
        val content: TextView = view.findViewById(R.id.tvNoteContent)
        val date: TextView = view.findViewById(R.id.tvNoteDate)
        val image: ImageView = view.findViewById(R.id.ivNoteImage)
        val link: MaterialButton = view.findViewById(R.id.btnOpenLink)
        val edit: ImageButton = view.findViewById(R.id.btnEditNote)
        val delete: ImageButton = view.findViewById(R.id.btnDeleteNote)
        val share: ImageButton = view.findViewById(R.id.btnShareNote)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NoteViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_note, parent, false)
        return NoteViewHolder(view)
    }

    override fun getItemCount(): Int = notes.size

    override fun onBindViewHolder(holder: NoteViewHolder, position: Int) {
        val note = notes[position]
        holder.title.text = note.title.ifBlank { "ملاحظة بدون عنوان" }
        holder.content.text = note.content.ifBlank { "بدون محتوى" }
        holder.date.text = formatter.format(Date(note.updatedAt))

        if (!note.imageUri.isNullOrBlank()) {
            holder.image.visibility = View.VISIBLE
            holder.image.setImageURI(Uri.parse(note.imageUri))
        } else {
            holder.image.visibility = View.GONE
            holder.image.setImageDrawable(null)
        }

        if (!note.linkUrl.isNullOrBlank()) {
            holder.link.visibility = View.VISIBLE
            holder.link.text = note.linkLabel?.ifBlank { "فتح الرابط" } ?: "فتح الرابط"
            holder.link.setOnClickListener { onOpenLink(note) }
        } else {
            holder.link.visibility = View.GONE
        }

        holder.card.setOnClickListener { onEdit(note) }
        holder.edit.setOnClickListener { onEdit(note) }
        holder.delete.setOnClickListener { onDelete(note) }
        holder.share.setOnClickListener { onShare(note) }
    }

    fun update(newNotes: List<Note>) {
        notes.clear()
        notes.addAll(newNotes)
        notifyDataSetChanged()
    }
}