package com.mariam.krar

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.webkit.WebView
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.mariam.krar.managers.ContactHelper
import com.mariam.krar.managers.WebViewManager
import com.mariam.krar.ui.dialogs.PrivacyDialog
import com.mariam.krar.utils.Constants

class MainActivity : AppCompatActivity() {

    private lateinit var webManager: WebViewManager
    private lateinit var webView: WebView

    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        webManager.onFileChosen(result.data, result.resultCode)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        webManager = WebViewManager(webView)
        webManager.setup()
        webManager.openFileChooserAction = { intent ->
            try {
                fileChooserLauncher.launch(intent ?: Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" })
            } catch (e: Exception) {
                fileChooserLauncher.launch(Intent(Intent.ACTION_GET_CONTENT).apply { type = "*/*" })
            }
        }

        // عناصر الواجهة
        val btnEmail = findViewById<View>(R.id.btnEmail)
        val btnGoogle = findViewById<View>(R.id.btnGoogle)
        val btnNext = findViewById<TextView>(R.id.btnNext)
        val cardEmail = findViewById<View>(R.id.cardEmail)
        val cardPassword = findViewById<View>(R.id.cardPassword)
        val etEmail = findViewById<EditText>(R.id.etEmail)
        val etPassword = findViewById<EditText>(R.id.etPassword)
        val btnWhatsapp = findViewById<View>(R.id.btnWhatsapp)
        val loginContainer = findViewById<LinearLayout>(R.id.loginContainer)

        // سياسة الخصوصية
        val prefs = getSharedPreferences(Constants.PREFS_NAME, MODE_PRIVATE)
        if (!prefs.getBoolean(Constants.KEY_PRIVACY_ACCEPTED, false)) {
            PrivacyDialog(this).show()
        }

        btnWhatsapp.setOnClickListener { ContactHelper.openWhatsapp(this) }

        btnEmail.setOnClickListener {
            cardEmail.visibility = View.VISIBLE
            btnNext.visibility = View.VISIBLE
            findViewById<View>(R.id.mainButtons).visibility = View.GONE
            btnNext.text = "التالي"
        }

        btnNext.setOnClickListener {
            if (etEmail.text.isNullOrEmpty()) return@setOnClickListener
            if (cardPassword.visibility == View.GONE) {
                cardPassword.visibility = View.VISIBLE
                btnNext.text = "دخول"
            } else {
                // هنا تسوي تسجيل دخولك وبعدها:
                loginContainer.visibility = View.GONE
                webView.visibility = View.VISIBLE
                webManager.loadHome()
            }
        }

        btnGoogle.setOnClickListener {
            loginContainer.visibility = View.GONE
            webView.visibility = View.VISIBLE
            webManager.loadHome()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}