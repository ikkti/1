package com.mariam.krar.ui.dialogs

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.widget.TextView
import com.mariam.krar.R
import com.mariam.krar.managers.ContactHelper
import com.mariam.krar.utils.Constants

class PrivacyDialog(context: Context) : Dialog(context) {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        // يثبت الحجم حتى الازرار تبين
        window?.setLayout((context.resources.displayMetrics.widthPixels * 0.90).toInt(), -2)
        setContentView(R.layout.dialog_privacy)
        setCancelable(false)

        findViewById<TextView>(R.id.tvPrivacyContent).text = """
            جمع البيانات لأغراض الذكاء الاصطناعي
            
            نلتزم في كروري فالفيردي بحماية خصوصيتك. نقوم بجمع بيانات محدودة لتحسين ميزات الذكاء الاصطناعي وتقديم تجربة مخصصة أكثر فعالية وأماناً.

            • البيانات التي نجمعها: النصوص والمدخلات التي تكتبها داخل التطبيق لتوفير وتحسين الردود الذكية، ومعلومات الاستخدام مثل الميزات المستخدمة ومدة الجلسة لتحسين الأداء، ومعلومات الجهاز الأساسية مثل نوع النظام وإصدار التطبيق لأغراض التشخيص وإصلاح الأخطاء.

            • كيف نستخدم البيانات: تُستخدم البيانات فقط لتدريب نماذج الذكاء الاصطناعي وتحسين جودة الخدمة، وتحليل الأنماط العامة لتحسين الاستقرار والأداء، ومنع إساءة الاستخدام والاحتيال.

            • مشاركة البيانات: لا نشارك بياناتك الشخصية مع أي طرف ثالث لأغراض تسويقية. قد نشاركها مع مزودي الخدمة الموثوقين الذين يساعدوننا في التشغيل والصيانة وفق التزامات سرية صارمة.

            • الاحتفاظ بالبيانات: نحتفظ بالبيانات للمدة اللازمة فقط لتقديم الخدمة وتحسينها، ويمكنك طلب حذف بياناتك في أي وقت.

            البريد الإلكتروني للنظام: ${Constants.SYSTEM_EMAIL} (لإرسال رموز التحقق فقط)
            الدعم الفني: ${Constants.SUPPORT_EMAIL}
        """.trimIndent()

        findViewById<TextView>(R.id.btnAccept).setOnClickListener {
            context.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putBoolean(Constants.KEY_PRIVACY_ACCEPTED, true).apply()
            dismiss()
        }
        findViewById<TextView>(R.id.btnReject).setOnClickListener {
            (context as? android.app.Activity)?.finishAffinity()
        }
        findViewById<TextView>(R.id.btnWhatsapp).setOnClickListener {
            ContactHelper.openWhatsapp(context)
        }
    }
}