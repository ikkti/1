package com.mariam.krar.managers
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser

class AuthManager {
    private val auth = FirebaseAuth.getInstance()
    fun checkVerified(onResult: (Boolean, FirebaseUser?) -> Unit) {
        val user = auth.currentUser
        user?.reload()?.addOnCompleteListener {
            val ok = user.isEmailVerified || user.providerData.any { p -> p.providerId == "google.com" }
            onResult(ok, user)
        } ?: onResult(false, null)
    }
}