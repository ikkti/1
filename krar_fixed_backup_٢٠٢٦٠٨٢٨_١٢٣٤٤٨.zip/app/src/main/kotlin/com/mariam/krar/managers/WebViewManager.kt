package com.mariam.krar.managers

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import com.mariam.krar.utils.Constants

object ContactHelper {
    fun openWhatsapp(context: Context) {
        val uri = Uri.parse("https://wa.me/${Constants.WHATSAPP_NUMBER}?text=مرحبا فريق كروري فالفيردي")
        context.startActivity(Intent(Intent.ACTION_VIEW, uri))
    }
}

class WebViewManager(private val webView: WebView) {
    var filePathCallback: ValueCallback<Array<Uri>>? = null
    var openFileChooserAction: ((Intent?) -> Unit)? = null

    @SuppressLint("SetJavaScriptEnabled")
    fun setup() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            userAgentString = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
            mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        }
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(webView: WebView?, filePathCallback: ValueCallback<Array<Uri>>?, fileChooserParams: FileChooserParams?): Boolean {
                this@WebViewManager.filePathCallback?.onReceiveValue(null)
                this@WebViewManager.filePathCallback = filePathCallback
                openFileChooserAction?.invoke(fileChooserParams?.createIntent())
                return true
            }
        }
    }

    fun loadHome() { webView.loadUrl(Constants.WEB_URL) }

    fun onFileChosen(data: Intent?, resultCode: Int) {
        var results: Array<Uri>? = null
        if (resultCode == Activity.RESULT_OK) {
            data?.let {
                val clip = it.clipData
                results = if (clip != null) {
                    Array(clip.itemCount) { i -> clip.getItemAt(i).uri }
                } else {
                    it.data?.let { uri -> arrayOf(uri) }
                }
            }
        }
        filePathCallback?.onReceiveValue(results)
        filePathCallback = null
    }
}